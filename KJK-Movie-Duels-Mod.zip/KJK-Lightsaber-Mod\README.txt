KJK Lightsaber Mod
==================

This mod adds Movie Duels' lightsaber creation, stances and player models to
KJK, which plays KOTOR's worlds with Jedi Academy's combat. It works in the
KOTOR 1 and the KOTOR 2 campaign.

No game files come with this mod. It reads KOTOR, Jedi Academy and Movie
Duels from your own installs and never changes them.


What you need
-------------
  - Windows 10 or 11, 64-bit, or a Steam Deck or Linux PC with Steam's
    Proton. The section "Steam Deck and Linux" below explains the steps.
  - Star Wars: Knights of the Old Republic II. KJK draws its menus and the
    Lightsaber Creation screen from it.
  - Star Wars Jedi Knight: Jedi Academy. KJK takes its movement, lightsaber
    combat and the Force from it.
  - Movie Duels, installed into Jedi Academy's GameData\MD folder. The mod
    takes its hilts, stances, sounds and player models from Movie Duels.
    The installer checks for MD_Hilts.pk3 and MD_Assets2.pk3 there.
  - Star Wars: Knights of the Old Republic, to play the KOTOR 1 campaign.
  - Microsoft's Visual C++ runtime (2015 to 2022), which Movie Duels needs
    too. Nearly every PC has it. If KJK does not start and Windows names
    vcruntime140.dll, install it from
    https://aka.ms/vs/17/release/vc_redist.x64.exe

Steam and GOG installs are found on their own. If Movie Duels is in another
folder, set the KJK_MOVIEDUELS environment variable to the folder that holds
MD_Hilts.pk3.


Installing
----------
1. Unpack this folder anywhere.
2. Run Install.bat.
3. The installer lists each game it found and each one it did not find. When
   everything is there, it installs the mod into %LOCALAPPDATA%\Programs\KJK,
   the folder KJK itself uses. It puts a "KJK Lightsaber Mod" shortcut on the
   desktop and in the Start menu.
4. If KJK is already installed there, the installer keeps your kjk.exe as
   kjk.exe.before-lightsaber-mod. Your saves and settings are not touched.

If a game is installed where the installer does not look, run
"Install.bat -Force". KJK's first-run setup then lets you choose the game
folders yourself.


Uninstalling
------------
Choose "Uninstall KJK Lightsaber Mod" in the Start menu. You can also run
Uninstall.bat in this folder. It puts your earlier kjk.exe back and removes
the shortcuts. Your saves and settings are kept.


Steam Deck and Linux
--------------------
Do not run Install.bat through Proton, Wine or protontricks. A Proton prefix
has no PowerShell, so Install.bat cannot install anything there.

1. Switch the Steam Deck to Desktop Mode.
2. Unpack this folder, for example into your Downloads folder.
3. Open the folder in the file manager. Right-click an empty spot and choose
   "Open Terminal Here".
4. Type "bash install.sh" and press Enter.
5. The installer finds KOTOR, KOTOR 2, Jedi Academy and Movie Duels in every
   Steam library, including one on a microSD card. It installs the mod into
   the folder .local/share/kjk-lightsaber-mod in your home folder.
6. In Steam, choose Games, then "Add a Non-Steam Game to My Library", and
   tick "KJK Lightsaber Mod". If it is not listed, choose Browse and pick
   kjk.exe in that folder.
7. Open the new entry's Properties, then Compatibility. Tick "Force the use
   of a specific Steam Play compatibility tool" and choose Proton
   Experimental or the newest Proton.
8. Start it from your library. It also shows in Game Mode from then on.

On its first start, KJK's setup asks where your games are. Under Proton, your
Linux folders are on drive Z. The installer prints the exact folders to
choose, such as Z:\home\deck\.local\share\Steam\steamapps\common\Jedi Academy.

To uninstall, run "bash install.sh --uninstall" in this folder, and remove the
entry from your Steam library.


What the mod adds
-----------------
Lightsaber Creation
  A screen in the style of Movie Duels' Lightsaber Creation menu. Open it
  from the workbench's Lightsaber button, or from the options' gameplay page.
  It has five tabs:
  - Hilt lists every Movie Duels hilt. Any lightsaber can take any hilt.
    The hilts made for the saber type being forged come first. Movie Duels'
    melee weapons, such as daggers, vibroswords and batons, come last.
  - Colour offers 11 blade colours.
  - Stance offers 27 Movie Duels fighting styles for five stance slots: the
    fast, medium and strong styles, two lightsabers, and a double-bladed
    lightsaber.
  - Saber type chooses the kind of lightsaber being forged: one lightsaber,
    the right or the left hand of two lightsabers, or a double-bladed
    lightsaber. Each kind keeps its own hilt and colour, so a character who
    changes what they hold shows the hilt made for it.
  - Character chooses the party member. Each companion keeps their own
    hilts, colours and stances. A companion with no stance of their own
    stands as your character does.
  A preview shows the hilt with its blade lit before you choose it.
  Choosing a hilt, a colour or a saber type also puts that kind of
  lightsaber in the character's hands, whatever they held before. The
  character takes one the party carries, or else a new basic lightsaber of
  that kind. Anyone can hold it, even a character without lightsaber
  training.

Stances
  The 27 stances are Movie Duels, Anakin, Ben Kenobi, Cal Kestis, Clone
  Trooper, Kyle Katarn (Dark Forces II), Count Dooku, Galen Marek, Qui-Gon
  Jinn, KOTOR, Luke Skywalker, Mace Windu, Darth Maul, Obi-Wan Kenobi, Obi-Wan
  (Episode III), Palpatine, Rebels, Kylo Ren, Rey, Darth Vader, Yoda, General
  Grievous, Jango Fett, Deka, Melee, Battle Droid and Super Battle Droid.
  Deka has only a medium stance. The Super Battle Droid has only a medium
  stance and a stance for two lightsabers. In their other slots the
  character takes Jedi Academy's normal pose.
  A character blends from one stance into the next over about a quarter of
  a second. A character turns their wrist so that the blade does not pass
  through their own head, body or legs.

Player models
  The Player model page draws your character or a companion as another
  model. Choose the party member at the top of the page, then the model. The
  page lists the campaign's player faces and the characters of Movie Duels'
  character select, era by era. A companion keeps their model through
  module changes and saves.
  Your own portrait changes with the model. A companion's portrait still
  shows their KOTOR face.
  Armour and helmets are drawn solid, as in Movie Duels. Only surfaces such
  as glass and hair, which Movie Duels draws see-through, let the
  background show.
  A Movie Duels character holds KOTOR's blasters as Jedi Academy's own
  characters hold theirs: the barrel runs along the forearm and points
  forward. This covers pistols, rifles and heavy repeaters.

Every change on these pages applies at once, without a restart. The section
"How to open each feature" below says where each page is.


How to open each feature
------------------------
Lightsaber Creation
  - Open the options. In game, press Esc (Start on a gamepad) and choose
    Options. In the main menu, choose Options. Then choose Gameplay, then
    the "Lightsaber Creation" button.
  - Or use a workbench. Choose its Lightsaber tab, then the wide
    "Lightsaber Creation" button at the bottom.
  - Choose a row with a click, or with the keyboard's or the gamepad's
    activate button. The choice is kept at once. There is nothing to
    confirm. Done closes the screen.

Stances
  - Stances are chosen in Lightsaber Creation, on its Stance tab.
  - The bar above the list says which stance slot the chosen stance goes
    into. Click the bar to step through all five slots, the fast style,
    the medium style, the strong style, two lightsabers and a
    double-bladed lightsaber.
  - In a fight, press L to switch between the fast, medium and strong
    style. The box beside your portrait shows the style in use while you
    hold a lightsaber.

Player model
  - Open the options and choose Graphics, then Interface. Choose the
    "Player model" row to open the Player model page.
  - Choose a model with a click. "As created" goes back to the body the
    game made for that character. Close leaves the page.

Changing a companion's model, lightsaber or stances
  - The Player model page and Lightsaber Creation's Character tab both
    list the characters in your current party. Your own character comes
    first, then the companions travelling with you (at most two).
  - Choose a companion's row first, then their model, hilt, colour or
    stances. Each companion keeps their own choices, also after they
    leave the party and come back.
  - A companion who is not in your party is not listed. Bring them into
    the party first, with KOTOR's own party selection. The game shows it
    when you leave the Ebon Hawk and at some story moments. Pressing P in
    play only shows who is in the party. It cannot change the party.

Force power wheel
  - Hold G, or LB and RT together on a gamepad, to open the wheel.
  - Aim with the mouse or the right stick, or scroll the mouse wheel, to
    pick a power. Let go of the key to choose it. F casts the chosen
    power.

Also in this build
  - Movie Duels Force powers on a power wheel: Force Blast, Force Repulse,
    Force Destruction, Electric Judgment, Force Projection, Deadly Sight,
    Force Grasp and Force Sense. Companions cast them in fights too.


Where things are kept
---------------------
Settings and saves:   %APPDATA%\kjk
Imported game data:   %LOCALAPPDATA%\kjk (safe to delete; it is made again)

The licences of KJK and of the code it is built from are in
lightsaber-mod-LICENSE.txt, lightsaber-mod-NOTICE.txt and
lightsaber-mod-THIRD-PARTY-LICENSES.html.


Credits
-------
KJK
  KJK is made by the kjk contributors and released under the MIT License.
  It plays Star Wars: Knights of the Old Republic's worlds with Star Wars
  Jedi Knight: Jedi Academy's movement, lightsabers and the Force. This mod
  is built on KJK v0.17.0 and keeps its licence (LICENSE.txt, NOTICE.txt).
  KJK learned how the original engines behave from OpenJK, reone and
  xoreos. No code from them is included.

Movie Duels
  The hilts, stances, animations, player models and Force powers this mod
  uses come from Star Wars: Movie Duels, which you install yourself. This
  mod ships none of its files.
  Movie Duels is made by the Movie Duels Team and Wector, who created the
  original Movie Duels 2 in 2009.
  The Movie Duels Team: Mike7704 (leader, coder, menus, scripter), Chloe
  (texture artist), GP (mapper, texture artist), Grimbord (modeller), Jace
  Solaris (coder), LangZ (sound editor), Lwkill (mapper, scripter),
  MasterJin (mapper), Mikcz (mapper, modeller), RealygirlLP (German
  translation), Tompa9 (modeller, scripter, Czech translation), Valzhar
  (coder), WC3 Tutorial (animator), Yeyo JK (texture artist) and Zinney
  (beta tester).
  Movie Duels' models, skins, sounds and maps are the work of many
  community artists. Each one is named in ReadMe_Credits.txt in your Movie
  Duels folder (Jedi Academy\GameData\MD\ReadMe).

The games
  Star Wars: Knights of the Old Republic was made by BioWare. Star Wars:
  Knights of the Old Republic II - The Sith Lords was made by Obsidian
  Entertainment. Star Wars Jedi Knight: Jedi Academy was made by Raven
  Software. All three were published by LucasArts. Star Wars and its names
  are trademarks of Lucasfilm. This mod is not affiliated with or endorsed
  by any of them.
